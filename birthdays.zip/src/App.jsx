import { useState } from "react";
import "./index.css";
import data from "./data/db";
import Fragment from "react";
import List from "./components/List";

function App() {
  const [people, setPeople] = useState(data);
  const deletePerson = (id) => {
    const newPeople = people.filter((person) => {
      return person.id !== id;
    });
    setPeople(newPeople);
  };
  return (
    <div className="container">
      <h1>{people ? people.length : 0}birthdays today</h1>
      <List people={people} deletePerson={deletePerson} />
      {people.length ? (
        <button
          className="clear-btn"
          onClick={() => {
            setPeople(null);
          }}
        >
          Clear All
        </button>
      ) : null}{" "}
      {!people.length && (
        <button
          className="clear-btn"
          onClick={() => {
            setPeople(data);
          }}
        >
          Refresh
        </button>
      )}
    </div>
  );
}

export default App;
